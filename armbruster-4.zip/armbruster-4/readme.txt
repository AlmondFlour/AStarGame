The source files include:
	� test.cpp		- holds main, handles initializing things and the game loop
	� entitity.h, .cpp	- defines 3 objects: Animator, GameObj, and Tile
	� handler.h, .cpp	- defines a Level, which is a means to handle most things in the game
	� astargame.cbp		- Code::Blocks project
	� SFML-2.1		- The graphics library
	� .png and .ttf files	- Resources used in the game; must be present to run


//Running insructions

L.Shift + click to add entities

All other commands are listed at the bottom of the screen when running,